package com.marvel.validation;

import java.util.List;
import java.util.Set;

public interface Validatable<T> {
	boolean validate(List<Validator<T>> validators, Set<String> errors);
}
