package com.marvel.validation;

import java.util.Set;

import com.marvel.exceptions.AnnotationProcessException;

public interface AnnotationValidator<T> {
	Set<String> processAnnotation(T t) throws AnnotationProcessException;
}
