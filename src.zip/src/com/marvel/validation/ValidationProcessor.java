package com.marvel.validation;

import java.util.Set;

public class ValidationProcessor<T> implements Validator<T> {

	@Override
	public boolean isValid(T t, Set<String> errors) {
		processValidations(t,errors);
		return false;
	}

	private void processValidations(T t, Set<String> errors) {
		AnnotationValidator<T> processor = AnnotationValidatorFactory.getFieldValidator(t);
		errors.addAll(processor.processAnnotation(t));
		
	}

}
