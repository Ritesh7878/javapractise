package com.marvel.validation;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;


import com.marvel.validation.annotation.AnnotationProcessor;
import com.marvel.validation.annotation.AnnotationProcessorFactory;


public class FieldValidator<T> implements AnnotationValidator<T> {

	@Override
	public Set<String> processAnnotation(T t) {
		Set<String> errors = new HashSet<>();
		 Class<?> objectClass = t.getClass();
		 for (Field field: objectClass.getDeclaredFields()) {
             field.setAccessible(true);
             for(Annotation ann : field.getAnnotations()){
            	AnnotationProcessor<T> processor = AnnotationProcessorFactory.getAnnotationProcessor(ann,t);
            	errors.addAll(processor.processAnnotation(ElementType.FIELD,field, t));
             }

         }
		return errors;
	}

}
