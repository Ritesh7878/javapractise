package com.marvel.validation;

import java.util.Set;

public interface Validator<T> {
	boolean isValid(T t,Set<String> errors);
}
