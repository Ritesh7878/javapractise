package com.marvel.validation;

public class AnnotationValidatorFactory {

	public static  <T> AnnotationValidator<T> getFieldValidator(T t) {
		return new FieldValidator<T>();
	}

}
