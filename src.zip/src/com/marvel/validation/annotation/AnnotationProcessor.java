package com.marvel.validation.annotation;

import java.lang.annotation.ElementType;
import java.util.Set;

public interface AnnotationProcessor<T> {
	

	 Set<String>  processAnnotation(ElementType type, Object obj, T t);

}
