package com.marvel.validation.annotation;

import java.lang.annotation.ElementType;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;

import com.marvel.exceptions.AnnotationProcessException;

public class NotNullProcessor<T> implements AnnotationProcessor<T> {

	

	@Override
	public Set<String> processAnnotation(ElementType type, Object obj, T t) {
		Set<String> errors = new HashSet<>();
		try {
			if(type.compareTo(ElementType.FIELD) == 0){
				Field field = (Field) obj;
				if(field.get(t) == null){
					errors.add(field.getAnnotation(NotNull.class).message());
				}
			}
			
				
		} catch (Exception e) {
			throw new AnnotationProcessException(e);
		}
		
		return errors;
		
	}

	
	
}
