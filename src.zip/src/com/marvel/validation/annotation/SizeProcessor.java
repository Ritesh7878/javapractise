package com.marvel.validation.annotation;


import java.lang.annotation.ElementType;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;

import com.marvel.exceptions.AnnotationProcessException;

public class SizeProcessor<T> implements AnnotationProcessor<T> {

	@Override
	public Set<String> processAnnotation(ElementType type, Object obj, T t) {
		Set<String> errors = new HashSet<>();
		try {
			if(type.compareTo(ElementType.FIELD) == 0){
				Field field = (Field) obj;
				Object fieldObj = field.get(t);
				if(fieldObj != null){
					String str = String.valueOf(fieldObj);
					if(str.length() > field.getAnnotation(Size.class).length())
					errors.add(field.getAnnotation(Size.class).message());
				}
			}
			
				
		} catch (Exception e) {
			throw new AnnotationProcessException(e);
		}
		
		return errors;
	}

}
