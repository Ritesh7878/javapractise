package com.marvel.validation.annotation;

import java.lang.annotation.Annotation;

import com.marvel.exceptions.AnnotationProcessException;

public class AnnotationProcessorFactory {

	public static <T> AnnotationProcessor<T> getAnnotationProcessor(Annotation ann, T t) {
		String className = ann.annotationType().getName()+"Processor";
		AnnotationProcessor<T> processor = null;
		try {
			Class<?> clazz = Class.forName(className);
			processor =  (AnnotationProcessor<T>) clazz.newInstance();
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			throw new AnnotationProcessException(e);
		}
		return processor;
	}

}
