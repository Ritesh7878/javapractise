package com.marvel.domain;

import java.util.List;
import java.util.Set;

import com.marvel.validation.Validatable;
import com.marvel.validation.Validator;
import com.marvel.validation.annotation.NotNull;
import com.marvel.validation.annotation.Size;

public class Patient implements Validatable<Patient> {
	
	
	@NotNull(message = "Patient Id can not be null")
	@Size(length=5, message="Patient id can not contains more than 5 chars")
	private String patientId;
	
	@NotNull(message = "Patient Name can not be null")
	private String name;
	
	@Size(length = 12, message = "Email chars should not exceed 12.")
	private String email;
	private Integer age;
	
	
	
	public Patient(String patientId, String name, String email, Integer age) {
		super();
		this.patientId = patientId;
		this.name = name;
		this.email = email;
		this.age = age;
	}



	public String getPatientId() {
		return patientId;
	}



	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public Integer getAge() {
		return age;
	}



	public void setAge(Integer age) {
		this.age = age;
	}



	@Override
	public boolean validate(List<Validator<Patient>> validators, Set<String> errors) {
		for(Validator<Patient> v : validators){
			v.isValid(this, errors);
		}
		return errors.isEmpty();
	}

}
