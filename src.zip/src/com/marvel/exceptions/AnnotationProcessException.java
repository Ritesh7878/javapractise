package com.marvel.exceptions;

public class AnnotationProcessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnnotationProcessException(Exception e) {
		super(e);
	}
	public AnnotationProcessException(Throwable cause) {
		super(cause);
		
	}
	public AnnotationProcessException(String message, Throwable cause) {
		super(message, cause);
	}
}
