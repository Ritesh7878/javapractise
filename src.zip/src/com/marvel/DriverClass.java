package com.marvel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.marvel.domain.Patient;
import com.marvel.validation.ValidationProcessor;
import com.marvel.validation.Validator;

public class DriverClass {
	public static void main(String args[]){
		Set<String> errors = new HashSet<>();
		Patient p = new Patient(null,null, "ritesh@gmail.com", 28);
		
		Validator<Patient> v = new ValidationProcessor<>();
		List<Validator<Patient>> validators = new ArrayList<>();
		validators.add(v);
		p.validate(validators, errors);
		System.out.println(errors);
		
	}
	
}
