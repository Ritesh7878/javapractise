package CCFramework;

public class AbstractCrudRepository {

	public void insert(DomainObject domainObject){
		
	}
	
}
