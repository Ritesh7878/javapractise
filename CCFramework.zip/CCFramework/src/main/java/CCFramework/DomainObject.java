package CCFramework;

public class DomainObject {

}
