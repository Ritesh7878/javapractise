package patient;

import java.util.List;

public interface PatientRepository {
	List<Patient> findByPatientName(final String patientName);
}
