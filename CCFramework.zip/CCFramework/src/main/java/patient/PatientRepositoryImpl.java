package patient;

import java.util.List;

import db.DataRepository;
import db.Repository;

public class PatientRepositoryImpl extends Repository<Patient> implements PatientRepository {
	
	PatientRepositoryImpl(){
		this.setRepository(new DataRepository());
	}
	
	@Override
	public List<Patient> findByPatientName(String patientName) {
		return read(patientName, null);
	}
	
	

}
