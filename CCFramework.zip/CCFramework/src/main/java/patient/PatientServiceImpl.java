package patient;

import java.util.List;

public class PatientServiceImpl implements PatientService {

	@Override
	public void addPatient(Patient p) {
		// TODO Auto-generated method stub

	}

	@Override
	public Integer updatePatient(Patient p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer deletePatient(Patient p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Patient findPatient(Integer patientId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Patient> findByPatientName(String patientName) {
		// TODO Auto-generated method stub
		return null;
	}

}
