package patient;

import java.util.List;

public interface PatientService {
	public void addPatient(Patient p);
	public Integer updatePatient(Patient p);
	public Integer deletePatient(Patient p);
	public Patient findPatient(Integer patientId);
	List<Patient> findByPatientName(final String patientName);
}
