package patient;

public class Patient {

}
