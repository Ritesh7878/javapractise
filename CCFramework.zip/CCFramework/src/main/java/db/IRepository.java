package db;

import java.util.List;

public interface IRepository<T> {
	List<T> read(String query, Object[] params);
}
