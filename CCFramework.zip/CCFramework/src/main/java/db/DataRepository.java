package db;

import java.util.List;

public class DataRepository extends RepositoryImpl {

	@Override
	public  <T> List<T> read(String query, Object[] params) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
