package db;

import java.util.List;

public abstract class RepositoryImpl {
	public abstract <T> List<T> read(String query, Object[] params);
}
