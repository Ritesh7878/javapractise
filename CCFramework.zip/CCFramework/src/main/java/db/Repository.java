package db;

import java.util.List;

public class Repository<T> implements IRepository<T> {
	
	private RepositoryImpl repositoryImpl = null;
	
	public void setRepository(RepositoryImpl repositoryImpl){
		this.repositoryImpl = repositoryImpl;
	}
	
	@Override
	public List<T> read(String query, Object[] params) {
		// TODO Auto-generated method stub
		return repositoryImpl.read(query, params);
	}
	
	
}
